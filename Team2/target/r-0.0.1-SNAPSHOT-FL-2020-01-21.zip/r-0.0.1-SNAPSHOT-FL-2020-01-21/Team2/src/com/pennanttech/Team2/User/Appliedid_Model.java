package com.pennanttech.Team2.User;

import java.sql.Date;

public class Appliedid_Model {
 
private String Company_Name;
private String Job_Role;
private String Job_Location;
private String Status;
private Date Applied_Date;
public Date getApplied_Date() {
	return Applied_Date;
}
public void setApplied_Date(Date d) {
	this.Applied_Date = d;
}
public String getJob_Location() {
	return Job_Location;
}
public void setJob_Location(String job_Location) {
	Job_Location = job_Location;
}


public String getCompany_Name() {
	return Company_Name;
}
public void setCompany_Name(String company_Name) {
	Company_Name = company_Name;
}
public String getJob_Role() {
	return Job_Role;
}
public void setJob_Role(String job_Role) {
	Job_Role = job_Role;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}

	
	
	
	
	
	
	
	
	
	
	
	
}
