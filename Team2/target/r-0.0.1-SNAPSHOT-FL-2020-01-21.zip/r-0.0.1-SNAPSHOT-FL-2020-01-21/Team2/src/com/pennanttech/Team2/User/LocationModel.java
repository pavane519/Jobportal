package com.pennanttech.Team2.User;

public class LocationModel {
	private String LocId;
	private String Location;
	
	public String getLocId() {
		return LocId;
	}
	public void setLocId(String locId) {
		LocId = locId;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	
	
	

}
